#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include <string>
using namespace std;
// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

// actor list: Peach, Yoshi
// Coin Squares, Star Squares, Directional Squares, Bank Squares, Event Squares, Dropping Squares
// Boo, Bowser, Vortexes
class StudentWorld;
class Actor : public GraphObject
{
	public: 
		Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* gameworld);
		virtual ~Actor();
		virtual void doSomething() = 0;
		StudentWorld* getWorld();
	private:
		StudentWorld* m_gameworld;	
};

class Player_Avatar : public Actor
{
	public:
		enum PlayerState
		{
			walking, waiting_to_roll
		};
		Player_Avatar(int imageID, int startX, int startY, int dir, int depth, double size, int player_number, StudentWorld* gameworld);
		virtual ~Player_Avatar();
		virtual void doSomething();
	private:	
		PlayerState m_state;
		int m_walkDir;
		int m_ticks_to_move;
		int m_player_number;
};

class Square : public Actor
{
	public:	
		Square(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* gameworld);
		virtual ~Square();
		//void checkPlayerOnSquare();
	private:
};

class Coin_Square : public Square
{
public:
	enum FlagState
	{
		alive, dead
	};
	enum CoinStatus
	{
		give3, take3
	};
	Coin_Square(int imageID, int startX, int startY, int dir, int depth, double size, CoinStatus coin_status, StudentWorld* gameworld);
	virtual ~Coin_Square();
	virtual void doSomething();
private:
	FlagState m_flag;
	CoinStatus m_coin_status;
};


#endif // ACTOR_H_
