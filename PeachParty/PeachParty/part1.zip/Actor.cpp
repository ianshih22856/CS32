#include "Actor.h"
#include "StudentWorld.h"
// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp


Actor::Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* gameworld)
	: GraphObject(imageID, startX, startY, dir, depth, size)
{
	m_gameworld = gameworld;
}
 Actor::~Actor()
{
	//delete actor stuff 
}
//void Actor::doSomething()
//{
	//do actor stuff
//}
 StudentWorld* Actor::getWorld()
 {
	 return m_gameworld;
 }

 Player_Avatar::Player_Avatar(int imageID, int startX, int startY, int dir, int depth, double size, int player_number, StudentWorld* gameworld)
	 :Actor(imageID, startX, startY, dir, depth, size, gameworld)
 {
	 m_state = waiting_to_roll;
	 m_ticks_to_move = 0;
	 m_player_number = player_number;
	 setDirection(dir);
	 m_walkDir = dir;
 }
 Player_Avatar::~Player_Avatar()
 {
	 //delete player stuff
 }
 void Player_Avatar::doSomething()
 {
	 if (m_state == waiting_to_roll)
	 {
		 if (getWorld()->getAction(m_player_number) == ACTION_ROLL)
		 {
			 int die_roll = randInt(1, 10);
			 m_ticks_to_move = die_roll * 8;
			 m_state = walking;
		 }
		 else
		 {
			 return;
		 }
	 }
	 if (m_state == walking)
	 {
		 int tempX;
		 int tempY;
		 getPositionInThisDirection(m_walkDir, SPRITE_WIDTH, tempX, tempY);
		 if (getWorld()->getBoard()->getContentsOf(tempX / SPRITE_WIDTH, tempY / SPRITE_HEIGHT) == Board::GridEntry::empty)
		 {
			 if (m_walkDir == left || m_walkDir == right)
			 {
				 int tempX1;
				 int tempY1;
				 getPositionInThisDirection(up, SPRITE_HEIGHT, tempX1, tempY1);
				 if (m_walkDir == left && getWorld()->getBoard()->getContentsOf((getX() - 2) / SPRITE_WIDTH, getY() / SPRITE_HEIGHT) != Board::GridEntry::empty && getX() > 0)
				 {
					 moveAtAngle(left, 2);
					 return;
				 }
				 if (getWorld()->getBoard()->getContentsOf(tempX1 / SPRITE_WIDTH, tempY1 / SPRITE_HEIGHT) != Board::GridEntry::empty && tempY1 < VIEW_HEIGHT)
				 {
						 setDirection(right);
						 m_walkDir = up;
				 }
				 else
				 {
					 setDirection(right);
					 m_walkDir = down;
				 }
			 }
			 else
			 {
				 int tempX2;
				 int tempY2;
				 getPositionInThisDirection(right, SPRITE_WIDTH, tempX2, tempY2);
				 if (m_walkDir == down && getWorld()->getBoard()->getContentsOf(getX() / SPRITE_WIDTH, (getY() - 2) / SPRITE_HEIGHT) != Board::GridEntry::empty && getY() > 0)
				 {
					 moveAtAngle(down, 2);
					 return;
				 }
				 if (getWorld()->getBoard()->getContentsOf(tempX2 / SPRITE_WIDTH, tempY2 / SPRITE_HEIGHT) != Board::GridEntry::empty && tempY2 < VIEW_HEIGHT)
				 {
					 setDirection(right);
					 m_walkDir = right;
				 }
				 else
				 {
					 setDirection(left);
					 m_walkDir = left;
				 }
			 }
		 }
		moveAtAngle(m_walkDir, 2);
		 m_ticks_to_move--;
		 if (m_ticks_to_move == 0)
			 m_state = waiting_to_roll;
	 }
 }

 Square::Square(int imageID, int startX, int startY, int dir, int depth, double size,StudentWorld* gameworld)
	 :Actor(imageID, startX, startY, dir, depth, size, gameworld)
 {
	//construct square stuff
 }
 Square::~Square()
 {
	 //delete square stuff
 }

 Coin_Square::Coin_Square(int imageID, int startX, int startY, int dir, int depth, double size, CoinStatus coin_status, StudentWorld* gameworld)
	 :Square(imageID, startX, startY, dir, depth, size, gameworld)
 {
	 m_coin_status = coin_status;
	 m_flag = alive;
	 //construct coin_square stuff
 }
 Coin_Square::~Coin_Square()
 {
	 //delete coin_square stuff
 }
 void Coin_Square::doSomething()
 {
	 if (m_flag == dead)
	 {
		 return;
	 }

 }