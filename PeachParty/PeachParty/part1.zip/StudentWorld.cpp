#include "StudentWorld.h"
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath)
{
    m_board = new Board();
}
StudentWorld::~StudentWorld()
{
    for (int i = 0; i < m_actors.size(); i++)
        delete m_actors.at(i);
    delete m_board;
}

Board* StudentWorld::getBoard()
{
    return m_board;
}
int StudentWorld::init()
{
    string board_file = this->assetPath() + "board0" + to_string(this->getBoardNumber()) + ".txt";
    if (m_board->loadBoard(board_file) == Board::LoadResult::load_success)
    {
        for (int i = 0; i < SPRITE_WIDTH; i++)
        {
            for (int j = 0; j < SPRITE_HEIGHT; j++)
            {
                Board::GridEntry result = m_board->getContentsOf(i, j);
                switch (result)
                {
                case Board::empty:
                    break;
                case Board::player:
                {
                    Player_Avatar* player = new Player_Avatar(IID_PEACH, SPRITE_WIDTH * i, SPRITE_HEIGHT * j, GraphObject::right, 0, 1, 1, this);
                    m_actors.push_back(player);
                    Coin_Square* blue_square = new Coin_Square(IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * i, SPRITE_HEIGHT * j, GraphObject::right, 1, 1,Coin_Square::CoinStatus::give3, this);
                    m_actors.push_back(blue_square);
                    break;
                }
                case Board::blue_coin_square:
                {
                    Coin_Square* blue_square = new Coin_Square(IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * i, SPRITE_HEIGHT * j, GraphObject::right, 1, 1, Coin_Square::CoinStatus::give3, this);
                    m_actors.push_back(blue_square);
                    break;
                }
                case Board::red_coin_square:
                {
                    Coin_Square* red_square = new Coin_Square(IID_RED_COIN_SQUARE, SPRITE_WIDTH * i, SPRITE_HEIGHT * j, GraphObject::right, 1, 1, Coin_Square::CoinStatus::take3, this);
                    m_actors.push_back(red_square);
                    break;
                }
                case Board::left_dir_square:
                case Board::right_dir_square:
                case Board::up_dir_square:
                case Board::down_dir_square:
                case Board::event_square:
                case Board::bank_square:
                case Board::star_square:
                case Board::boo:
                case Board::bowser:
                {
                    //blue squares to fill up other things
                    Coin_Square* blue_square = new Coin_Square(IID_BLUE_COIN_SQUARE, SPRITE_WIDTH * i, SPRITE_HEIGHT * j, GraphObject::right, 1, 1, Coin_Square::CoinStatus::give3, this);
                    m_actors.push_back(blue_square);
                    break;
                }
                }
            }
        }
        startCountdownTimer(99);
        return GWSTATUS_CONTINUE_GAME;
    }
    else
        return GWSTATUS_BOARD_ERROR;
}

int StudentWorld::move()
{
    // This code is here merely to allow the game to build, run, and terminate after you hit ESC.
    // Notice that the return value GWSTATUS_NOT_IMPLEMENTED will cause our framework to end the game.
    
    
    if (timeRemaining() <= 0)
    {
        playSound(SOUND_GAME_FINISHED);
        return GWSTATUS_PEACH_WON;
    }
    for (int i = 0; i < m_actors.size(); i++)
    {
        m_actors.at(i)->doSomething();
    }
    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
    for (int i = 0; i < m_actors.size(); i++)
        delete m_actors.at(i);
    delete m_board;
}
